function show() {
  document.getElementById("pa1").className="show";
}